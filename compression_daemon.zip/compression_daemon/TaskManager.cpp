#include "TaskManager.h"
#include <iostream>
#include <vector>
#include <string>
#include <thread>
#include <mutex>
#include <queue>
#include <atomic>
#include <algorithm>
#include <iomanip>
#include <chrono>

#ifdef _WIN32
#include <windows.h>
#include <psapi.h>
#endif

struct ProcessStat {
    unsigned long pid;
    std::string name;
    size_t memory_kb;
    double cpu_time_ms;
};

void run_task_manager() {
    std::cout << "\nStarting Multithreaded Task Manager...\n";
    std::atomic<bool> stop_flag{false};
    
    // Background thread to listen for ENTER key to gracefully exit
    std::thread input_thread([&stop_flag]() {
        std::cin.get();
        stop_flag = true;
    });

    const int NUM_THREADS = 8; // Thread pool size for the task manager

    while (!stop_flag) {
#ifdef _WIN32
        DWORD aProcesses[1024], cbNeeded, cProcesses;
        if (!EnumProcesses(aProcesses, sizeof(aProcesses), &cbNeeded)) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }
        cProcesses = cbNeeded / sizeof(DWORD);

        std::queue<DWORD> pid_queue;
        for (unsigned int i = 0; i < cProcesses; i++) {
            if (aProcesses[i] != 0) {
                pid_queue.push(aProcesses[i]);
            }
        }

        std::mutex q_mutex;
        std::mutex res_mutex;
        std::vector<ProcessStat> results;
        
        auto worker = [&]() {
            while (!stop_flag) {
                DWORD pid = 0;
                {
                    std::lock_guard<std::mutex> lock(q_mutex);
                    if (pid_queue.empty()) break;
                    pid = pid_queue.front();
                    pid_queue.pop();
                }

                HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
                if (hProcess) {
                    ProcessStat stat;
                    stat.pid = pid;
                    
                    char szProcessName[MAX_PATH] = "<unknown>";
                    HMODULE hMod;
                    DWORD cbNeededMod;
                    if (EnumProcessModules(hProcess, &hMod, sizeof(hMod), &cbNeededMod)) {
                        GetModuleBaseNameA(hProcess, hMod, szProcessName, sizeof(szProcessName)/sizeof(char));
                    }
                    stat.name = szProcessName;

                    PROCESS_MEMORY_COUNTERS pmc;
                    if (GetProcessMemoryInfo(hProcess, &pmc, sizeof(pmc))) {
                        stat.memory_kb = pmc.WorkingSetSize / 1024;
                    } else {
                        stat.memory_kb = 0;
                    }

                    FILETIME ftCreation, ftExit, ftKernel, ftUser;
                    if (GetProcessTimes(hProcess, &ftCreation, &ftExit, &ftKernel, &ftUser)) {
                        ULARGE_INTEGER kTime, uTime;
                        kTime.LowPart = ftKernel.dwLowDateTime;
                        kTime.HighPart = ftKernel.dwHighDateTime;
                        uTime.LowPart = ftUser.dwLowDateTime;
                        uTime.HighPart = ftUser.dwHighDateTime;
                        stat.cpu_time_ms = (kTime.QuadPart + uTime.QuadPart) / 10000.0;
                    } else {
                        stat.cpu_time_ms = 0;
                    }

                    {
                        std::lock_guard<std::mutex> lock(res_mutex);
                        results.push_back(stat);
                    }
                    CloseHandle(hProcess);
                }
            }
        };

        std::vector<std::thread> threads;
        for (int i=0; i<NUM_THREADS; ++i) {
            threads.emplace_back(worker);
        }
        for (auto& t : threads) {
            t.join();
        }

        // Sort by memory usage descending
        std::sort(results.begin(), results.end(), [](const ProcessStat& a, const ProcessStat& b) {
            return a.memory_kb > b.memory_kb;
        });

        // Clear screen using ANSI escape codes for a smooth top-like refresh
        std::cout << "\033[2J\033[1;1H";
        std::cout << "\033[36m========================================================================\n";
        std::cout << " MULTITHREADED TASK MANAGER (8 Worker Threads) - Press ENTER to exit\n";
        std::cout << "========================================================================\033[0m\n";
        std::cout << std::left << std::setw(10) << "PID" 
                  << std::setw(30) << "Process Name" 
                  << std::setw(15) << "Memory (MB)" 
                  << "CPU Time (ms)\n";
        std::cout << "------------------------------------------------------------------------\n";
        
        for (size_t i = 0; i < std::min((size_t)15, results.size()); i++) {
            std::cout << std::left << std::setw(10) << results[i].pid 
                      << std::setw(30) << results[i].name.substr(0, 29)
                      << std::setw(15) << std::fixed << std::setprecision(2) << (results[i].memory_kb / 1024.0)
                      << std::fixed << std::setprecision(0) << results[i].cpu_time_ms << "\n";
        }
        std::cout << "\033[36m========================================================================\033[0m\n";

        // Sleep before refreshing
        for (int i = 0; i < 10 && !stop_flag; ++i) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
#else
        std::cout << "This feature requires Windows.\n";
        stop_flag = true;
#endif
    }

    input_thread.join();
    std::cout << "\033[2J\033[1;1H"; // Clear screen on exit
    std::cout << "Task Manager shutdown complete.\n";
}

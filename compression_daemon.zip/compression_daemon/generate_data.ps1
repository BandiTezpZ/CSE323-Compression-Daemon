$chunk = "HELLO " * 100000
$path = "target_dir\massive_dataset.txt"
[IO.File]::WriteAllText($path, "")
for ($i=1; $i -le 500; $i++) {
    [IO.File]::AppendAllText($path, $chunk)
}

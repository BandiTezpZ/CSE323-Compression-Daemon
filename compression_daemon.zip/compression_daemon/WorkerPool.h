#ifndef WORKER_POOL_H
#define WORKER_POOL_H

#include <vector>
#include <thread>
#include "Monitor.h"

class WorkerPool {
private:
    std::vector<std::thread> workers_;
    Monitor* monitor_;
    size_t chunk_size_;

    void worker_loop(int worker_id);

public:
    WorkerPool(size_t num_threads, Monitor* monitor, size_t chunk_size);
    ~WorkerPool();
    
    void join_all();
};

#endif

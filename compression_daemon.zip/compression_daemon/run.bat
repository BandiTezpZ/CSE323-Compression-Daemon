@echo off
title File Compression Daemon
cls

:menu
echo =======================================================
echo    FILE COMPRESSION DAEMON - OS BENCHMARK UTILITY
echo =======================================================
echo [1] Compare Performance (FIFO vs SRPT)
echo [2] Start Live System Daemon (Background File Watcher)
echo [3] Run Baseline Only (FIFO)
echo [4] Run Optimized Only (SRPT)
echo [5] Generate 300MB Test Dataset
echo [6] Clean Compressed Files (*.z)
echo [7] Live Multithreaded Task Manager
echo [0] Exit
echo =======================================================
set /p choice="Select an option: "

if "%choice%"=="1" goto compare
if "%choice%"=="2" goto daemon
if "%choice%"=="3" goto fifo
if "%choice%"=="4" goto srpt
if "%choice%"=="5" goto generate
if "%choice%"=="6" goto clean
if "%choice%"=="7" goto taskmgr
if "%choice%"=="0" exit

echo Invalid choice.
timeout /t 2 >nul
cls
goto menu

:compare
cls
.\build\compression_daemon.exe target_dir --compare
pause
cls
goto menu

:daemon
cls
.\build\compression_daemon.exe target_dir --daemon
pause
cls
goto menu

:fifo
cls
.\build\compression_daemon.exe target_dir --fifo
pause
cls
goto menu

:srpt
cls
.\build\compression_daemon.exe target_dir --srpt
pause
cls
goto menu

:generate
cls
echo Generating massive 300MB dataset... Please wait.
powershell -ExecutionPolicy Bypass -File generate_data.ps1
echo Done!
pause
cls
goto menu

:clean
cls
echo Cleaning all compressed .z files in target_dir...
del /q target_dir\*.z
echo Cleaned!
pause
cls
goto menu

:taskmgr
cls
.\build\compression_daemon.exe --task-manager
cls
goto menu


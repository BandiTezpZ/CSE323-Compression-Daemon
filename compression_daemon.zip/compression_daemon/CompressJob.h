#ifndef COMPRESS_JOB_H
#define COMPRESS_JOB_H

#include <string>

enum class IOStrategy {
    IO_MMAP,
    IO_PREAD
};

struct CompressJob {
    std::string filename;
    size_t total_size;
    size_t remaining_bytes;
    size_t current_offset;
    IOStrategy strategy;

    // We want a min-heap based on remaining_bytes for SRPT (Shortest Remaining Processing Time).
    // The std::priority_queue returns the largest element first, so we invert the logic:
    // returning true if our remaining_bytes is LARGER than the other, pushing smaller jobs to the top.
    bool operator<(const CompressJob& other) const {
        return remaining_bytes > other.remaining_bytes;
    }
};

#endif

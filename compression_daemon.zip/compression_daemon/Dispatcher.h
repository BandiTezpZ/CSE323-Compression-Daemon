#ifndef DISPATCHER_H
#define DISPATCHER_H

#include <string>
#include "Monitor.h"

#include <atomic>

class Dispatcher {
private:
    Monitor* monitor_;
    std::string target_dir_;
    std::atomic<bool> stop_daemon_{false};

public:
    Dispatcher(Monitor* monitor, const std::string& target_dir);
    
    // Scans the directory once and pushes all files to the queue
    void scan_and_dispatch();

    // ADVANCED FEATURE: Runs infinitely, watching for new files dropped by the user
    void watch_directory();

    void stop() {
        stop_daemon_ = true;
    }
};

#endif

#ifndef POSIX_COMPAT_H
#define POSIX_COMPAT_H

#ifdef _WIN32
#include <windows.h>
#include <psapi.h>
#include <io.h>
#include <fcntl.h>

#ifndef O_BINARY
#define O_BINARY _O_BINARY
#endif

#ifndef __MINGW32__
#include <BaseTsd.h>
typedef SSIZE_T ssize_t;
#endif

// Polyfill for POSIX pread on Windows
inline ssize_t pread(int fd, void *buf, size_t count, long long offset) {
    HANDLE hFile = (HANDLE)_get_osfhandle(fd);
    if (hFile == INVALID_HANDLE_VALUE) return -1;
    
    OVERLAPPED overlapped = {0};
    overlapped.Offset = (DWORD)offset;
    overlapped.OffsetHigh = (DWORD)((unsigned long long)offset >> 32);
    
    DWORD bytesRead = 0;
    if (ReadFile(hFile, buf, count, &bytesRead, &overlapped)) {
        return bytesRead;
    }
    return -1;
}

#define RUSAGE_SELF 0
#ifndef __MINGW32__
struct timeval {
    long tv_sec;
    long tv_usec;
};
#endif

struct rusage {
    long ru_maxrss;
    struct timeval ru_utime;
    struct timeval ru_stime;
};

// Polyfill for POSIX getrusage on Windows
inline int getrusage(int who, struct rusage *usage) {
    if (who != RUSAGE_SELF || !usage) return -1;
    
    PROCESS_MEMORY_COUNTERS pmc;
    if (GetProcessMemoryInfo(GetCurrentProcess(), &pmc, sizeof(pmc))) {
        usage->ru_maxrss = pmc.PeakWorkingSetSize / 1024; // Convert to KB
    } else {
        usage->ru_maxrss = 0;
    }
    
    FILETIME creationTime, exitTime, kernelTime, userTime;
    if (GetProcessTimes(GetCurrentProcess(), &creationTime, &exitTime, &kernelTime, &userTime)) {
        ULARGE_INTEGER kTime, uTime;
        kTime.LowPart = kernelTime.dwLowDateTime;
        kTime.HighPart = kernelTime.dwHighDateTime;
        uTime.LowPart = userTime.dwLowDateTime;
        uTime.HighPart = userTime.dwHighDateTime;
        
        usage->ru_stime.tv_sec = (long)(kTime.QuadPart / 10000000);
        usage->ru_stime.tv_usec = (long)((kTime.QuadPart % 10000000) / 10);
        usage->ru_utime.tv_sec = (long)(uTime.QuadPart / 10000000);
        usage->ru_utime.tv_usec = (long)((uTime.QuadPart % 10000000) / 10);
    } else {
        usage->ru_stime.tv_sec = 0; usage->ru_stime.tv_usec = 0;
        usage->ru_utime.tv_sec = 0; usage->ru_utime.tv_usec = 0;
    }
    return 0;
}

// Polyfill for POSIX mmap on Windows
#define PROT_READ 1
#define MAP_PRIVATE 2
#define MAP_FAILED ((void *)-1)

inline void* mmap(void* addr, size_t length, int prot, int flags, int fd, long long offset) {
    HANDLE hFile = (HANDLE)_get_osfhandle(fd);
    if (hFile == INVALID_HANDLE_VALUE) return MAP_FAILED;
    
    HANDLE hMapping = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
    if (!hMapping) return MAP_FAILED;
    
    DWORD offsetHigh = (DWORD)((unsigned long long)offset >> 32);
    DWORD offsetLow = (DWORD)(offset & 0xFFFFFFFF);
    
    void* mapView = MapViewOfFile(hMapping, FILE_MAP_READ, offsetHigh, offsetLow, length);
    CloseHandle(hMapping); // Safe to close after mapping
    
    if (!mapView) return MAP_FAILED;
    return mapView;
}

inline int munmap(void* addr, size_t length) {
    if (UnmapViewOfFile(addr)) {
        return 0;
    }
    return -1;
}

#else

// Standard POSIX headers for Linux/macOS
#include <sys/resource.h>
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>

#ifndef O_BINARY
#define O_BINARY 0
#endif

#endif // _WIN32
#endif // POSIX_COMPAT_H

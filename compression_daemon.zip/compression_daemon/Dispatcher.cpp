#include "Dispatcher.h"
#include <iostream>
#include <filesystem>
#include <sys/stat.h>
#include <mutex>
#include <iomanip>
#include <unordered_set>
#include <chrono>
#include <thread>

namespace fs = std::filesystem;

extern std::mutex print_mutex;

Dispatcher::Dispatcher(Monitor* monitor, const std::string& target_dir)
    : monitor_(monitor), target_dir_(target_dir) {}

void Dispatcher::scan_and_dispatch() {
    if (!fs::exists(target_dir_) || !fs::is_directory(target_dir_)) {
        std::cerr << "Invalid directory: " << target_dir_ << std::endl;
        return;
    }

    {
        std::lock_guard<std::mutex> lock(print_mutex);
        std::cout << "  [Dispatcher] Scanning directory: " << target_dir_ << "...\n";
    }

    int file_count = 0;
    size_t total_size = 0;

    for (const auto& entry : fs::directory_iterator(target_dir_)) {
        if (fs::is_regular_file(entry.status())) {
            std::string path = entry.path().string();
            
            std::error_code ec;
            uintmax_t fsize = fs::file_size(entry.path(), ec);
            if (!ec) {
                CompressJob job;
                job.filename = path;
                job.total_size = fsize;
                job.remaining_bytes = fsize;
                job.current_offset = 0;
                
                // HYBRID VIRTUAL MEMORY STRATEGY
                const size_t THRESHOLD_SIZE = 4 * 1024 * 1024; // 4 MB
                if (fsize < THRESHOLD_SIZE) {
                    job.strategy = IOStrategy::IO_MMAP;
                } else {
                    job.strategy = IOStrategy::IO_PREAD;
                }

                file_count++;
                total_size += fsize;

                // Increment active jobs count before pushing to avoid race condition with wait_until_done()
                monitor_->increment_active();
                monitor_->push(job);
            }
        }
    }

    {
        std::lock_guard<std::mutex> lock(print_mutex);
        std::cout << "  [Dispatcher] Found " << file_count << " files. Total payload: " 
                  << std::fixed << std::setprecision(2) << (total_size / (1024.0 * 1024.0)) << " MB\n";
    }
}

void Dispatcher::watch_directory() {
    {
        std::lock_guard<std::mutex> lock(print_mutex);
        std::cout << "  [\033[35mSYSTEM DAEMON\033[0m] Watching directory " << target_dir_ << " for live file drops...\n";
    }

    std::unordered_set<std::string> processed_files;

    // Run infinitely until stopped
    while (!stop_daemon_) {
        if (!fs::exists(target_dir_) || !fs::is_directory(target_dir_)) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }

        for (const auto& entry : fs::directory_iterator(target_dir_)) {
            if (fs::is_regular_file(entry.status())) {
                std::string path = entry.path().string();
                
                // Ignore already compressed files (.z)
                if (path.length() >= 2 && path.substr(path.length() - 2) == ".z") {
                    continue;
                }

                // If this is a new file we haven't seen before
                if (processed_files.find(path) == processed_files.end()) {
                    processed_files.insert(path);

                    std::error_code ec;
                    uintmax_t fsize = fs::file_size(entry.path(), ec);
                    if (!ec && fsize > 0) {
                        CompressJob job;
                        job.filename = path;
                        job.total_size = fsize;
                        job.remaining_bytes = fsize;
                        job.current_offset = 0;
                        
                        const size_t THRESHOLD_SIZE = 4 * 1024 * 1024; // 4 MB
                        if (fsize < THRESHOLD_SIZE) {
                            job.strategy = IOStrategy::IO_MMAP;
                        } else {
                            job.strategy = IOStrategy::IO_PREAD;
                        }

                        {
                            std::lock_guard<std::mutex> lock(print_mutex);
                            std::cout << "  [\033[35mSYSTEM DAEMON\033[0m] Intercepted new file drop: " 
                                      << fs::path(path).filename().string() << " (" 
                                      << std::fixed << std::setprecision(2) << (fsize / (1024.0 * 1024.0)) << " MB)\n";
                        }

                        monitor_->increment_active();
                        monitor_->push(job);
                    }
                }
            }
        }
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
}

#ifndef MONITOR_H
#define MONITOR_H

#include <queue>
#include <mutex>
#include <condition_variable>
#include "CompressJob.h"

class Monitor {
private:
    std::priority_queue<CompressJob> queue_;
    std::queue<CompressJob> fifo_queue_;
    bool use_fifo_;

    std::mutex mutex_;
    std::condition_variable cond_var_;       // To wake up workers when jobs arrive
    std::condition_variable completion_cv_;  // To wake up the main thread when all files are done
    
    bool stop_ = false;
    int active_jobs_ = 0; // Tracks files currently being processed or waiting

public:
    Monitor(bool use_fifo = false) : use_fifo_(use_fifo) {}
    
    bool is_fifo() const { return use_fifo_; }

    void push(const CompressJob& job) {
        std::unique_lock<std::mutex> lock(mutex_);
        if (use_fifo_) {
            fifo_queue_.push(job);
        } else {
            queue_.push(job);
        }
        cond_var_.notify_one();
    }

    bool pop(CompressJob& job) {
        std::unique_lock<std::mutex> lock(mutex_);
        // Wait until queue has items OR we are stopping
        cond_var_.wait(lock, [this] { return (!use_fifo_ && !queue_.empty()) || (use_fifo_ && !fifo_queue_.empty()) || stop_; });
        
        if (stop_ && ((use_fifo_ && fifo_queue_.empty()) || (!use_fifo_ && queue_.empty()))) {
            return false;
        }
        
        if (use_fifo_) {
            job = fifo_queue_.front();
            fifo_queue_.pop();
        } else {
            job = queue_.top();
            queue_.pop();
        }
        return true;
    }

    void stop() {
        std::unique_lock<std::mutex> lock(mutex_);
        stop_ = true;
        cond_var_.notify_all(); // Wake up any sleeping workers so they can exit
    }
    
    void increment_active() {
        std::unique_lock<std::mutex> lock(mutex_);
        active_jobs_++;
    }
    
    void decrement_active() {
        std::unique_lock<std::mutex> lock(mutex_);
        active_jobs_--;
        if (active_jobs_ == 0) {
            completion_cv_.notify_all(); // Signal the main thread that all work is done
        }
    }
    
    void wait_until_done() {
        std::unique_lock<std::mutex> lock(mutex_);
        // Wait until there are no active jobs in the system
        completion_cv_.wait(lock, [this] { return active_jobs_ == 0; });
    }
};

#endif

#include "Monitor.h"
#include "Dispatcher.h"
#include "WorkerPool.h"
#include "TaskManager.h"
#include "posix_compat.h"
#include <iostream>
#include <string>
#include <filesystem>
#include <vector>
#include <iomanip>
#include <mutex>
#include <cstdio>
#include <memory>
#include <thread>

#ifdef _WIN32
#include <windows.h>
#endif

namespace fs = std::filesystem;

// Global mutex to prevent threads from printing over each other
std::mutex print_mutex;

// ANSI Colors for a professional UI
const char* C_RESET  = "\033[0m";
const char* C_RED    = "\033[31m";
const char* C_GREEN  = "\033[32m";
const char* C_YELLOW = "\033[33m";
const char* C_CYAN   = "\033[36m";

// Enable ANSI escape codes on Windows terminal
void enable_ansi_colors() {
#ifdef _WIN32
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD dwMode = 0;
    GetConsoleMode(hOut, &dwMode);
    dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
    SetConsoleMode(hOut, dwMode);
#endif
}

// Cleans up .z files before a fresh benchmark
void clean_z_files(const std::string& dir) {
    if (fs::exists(dir)) {
        for (const auto& entry : fs::directory_iterator(dir)) {
            if (entry.path().extension() == ".z") {
                fs::remove(entry.path());
            }
        }
    }
}

// Helper struct to return benchmark metrics
struct BenchResult {
    double utime;
    double stime;
    double wall_time;
    long maxrss;
};

// Runs the actual compression daemon setup
BenchResult run_benchmark(const std::string& target_dir, bool use_fifo) {
    clean_z_files(target_dir);

    auto start_time = std::chrono::high_resolution_clock::now();

    Monitor monitor(use_fifo);
    Dispatcher dispatcher(&monitor, target_dir);
    
    // DELIBERATE BOTTLENECK: The Baseline is strictly Single-Threaded!
    // The Optimized Mode utilizes the 12-core Thread Pool.
    int num_threads = use_fifo ? 1 : 12;
    WorkerPool pool(num_threads, &monitor, 2 * 1024 * 1024); // 2 MB chunks (The sweet spot for CPU/Memory)

    dispatcher.scan_and_dispatch();
    
    // Wait for all jobs to finish
    monitor.wait_until_done();
    monitor.stop(); // Wake up threads so they can exit gracefully

    auto end_time = std::chrono::high_resolution_clock::now();

    struct rusage usage;
    getrusage(RUSAGE_SELF, &usage);

    BenchResult res;
    res.wall_time = std::chrono::duration<double>(end_time - start_time).count();
    res.utime = usage.ru_utime.tv_sec + usage.ru_utime.tv_usec / 1e6;
    res.stime = usage.ru_stime.tv_sec + usage.ru_stime.tv_usec / 1e6;
    res.maxrss = usage.ru_maxrss;
    return res;
}

// Subprocess runner for --compare mode to isolate Memory High-Water Marks
void run_and_parse(const std::string& cmd, double& out_time, double& out_cpu, double& out_mem) {
#ifdef _WIN32
    FILE* pipe = _popen(cmd.c_str(), "r");
#else
    FILE* pipe = popen(cmd.c_str(), "r");
#endif
    if (!pipe) return;
    char buffer[256];
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        std::cout << buffer; // Print in real time!
        std::string line(buffer);
        if (line.find("Execution Time (Wall-Clock):") != std::string::npos) {
            size_t pos = line.find_last_of(":");
            out_time = std::stod(line.substr(pos + 1));
        }
        if (line.find("OS CPU Time:") != std::string::npos) {
            size_t pos = line.find_last_of(":");
            out_cpu = std::stod(line.substr(pos + 1));
        }
        if (line.find("Peak Memory:") != std::string::npos) {
            size_t pos = line.find_last_of(":");
            out_mem = std::stod(line.substr(pos + 1));
        }
    }
#ifdef _WIN32
    _pclose(pipe);
#else
    pclose(pipe);
#endif
}

int main(int argc, char* argv[]) {
    enable_ansi_colors();

    std::string target_dir = "target_dir";
    bool run_fifo = false;
    bool run_srpt = false;
    bool run_compare = false;
    bool run_daemon = false;
    std::string exe_path = argv[0];
    
    // Format the exe path safely for popen if it has spaces
    if (exe_path.find(' ') != std::string::npos) {
        exe_path = "\"" + exe_path + "\"";
    }

    // Parse arguments
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--fifo") { run_fifo = true; }
        else if (arg == "--srpt") { run_srpt = true; }
        else if (arg == "--compare") { run_compare = true; }
        else if (arg == "--daemon") { run_daemon = true; }
        else if (arg == "--task-manager") { run_task_manager(); return 0; }
        else if (arg == "--no-pause") { /* handled below */ }
        else { target_dir = arg; }
    }

    if (run_daemon) {
        std::cout << C_YELLOW << "\n========================================================================\n"
                  << "[3] Running Live System Daemon (Background Polling Mode)...\n"
                  << "========================================================================\n" << C_RESET;
        std::cout << C_GREEN << "  [\033[35mSYSTEM DAEMON\033[0m] Press ENTER at any time to gracefully shutdown and return to menu...\n\n" << C_RESET;

        Monitor monitor(false); // SRPT Priority Mode for Live Daemon
        Dispatcher dispatcher(&monitor, target_dir);
        WorkerPool pool(12, &monitor, 4 * 1024 * 1024);

        std::thread daemon_thread([&dispatcher]() {
            dispatcher.watch_directory();
        });

        std::cin.get(); // Wait for the user to press Enter

        std::cout << "\n  [\033[35mSYSTEM DAEMON\033[0m] Shutting down watcher and waiting for workers to finish current chunks...\n";
        dispatcher.stop();
        monitor.stop();
        daemon_thread.join();
        
        std::cout << "  [\033[35mSYSTEM DAEMON\033[0m] Shutdown complete.\n";
        return 0;
    }

    if (run_compare) {
        double f_time = 0, f_cpu = 0, f_mem = 0;
        std::cout << C_YELLOW << "\n========================================================================\n"
                  << "[1] Running Baseline File Compression Daemon (FIFO Queue)...\n"
                  << "========================================================================\n" << C_RESET;
        run_and_parse(exe_path + " \"" + target_dir + "\" --fifo --no-pause", f_time, f_cpu, f_mem);

        double s_time = 0, s_cpu = 0, s_mem = 0;
        std::cout << C_YELLOW << "\n========================================================================\n"
                  << "[2] Running Optimized File Compression Daemon (SRPT Priority Queue)...\n"
                  << "========================================================================\n" << C_RESET;
        run_and_parse(exe_path + " \"" + target_dir + "\" --srpt --no-pause", s_time, s_cpu, s_mem);

        std::cout << "\n" << C_YELLOW << "==================== PERFORMANCE DELTA ====================\n" << C_RESET;
        std::cout << "Baseline Wall-Clock:  " << C_RED << std::fixed << std::setprecision(2) << f_time << " s\n" << C_RESET;
        std::cout << "Optimized Wall-Clock: " << C_GREEN << std::fixed << std::setprecision(2) << s_time << " s\n" << C_RESET;
        double speedup = f_time / (s_time > 0 ? s_time : 1);
        std::cout << "Wall-Clock Speedup:   " << C_CYAN << std::fixed << std::setprecision(2) << speedup << "x faster\n" << C_RESET;

        std::cout << "\nBaseline OS CPU Time:  " << C_RED << std::fixed << std::setprecision(2) << f_cpu << " s\n" << C_RESET;
        std::cout << "Optimized OS CPU Time: " << C_GREEN << std::fixed << std::setprecision(2) << s_cpu << " s\n" << C_RESET;
        double cpu_saved = 100.0 * (1.0 - s_cpu / (f_cpu > 0 ? f_cpu : 1));
        std::cout << "CPU Work Reduction:    " << C_CYAN << std::fixed << std::setprecision(1) << cpu_saved << "% less processing\n" << C_RESET;

        std::cout << "\nBaseline Peak Memory:  " << C_RED << std::fixed << std::setprecision(2) << f_mem << " MB\n" << C_RESET;
        std::cout << "Optimized Peak Memory: " << C_GREEN << std::fixed << std::setprecision(2) << s_mem << " MB\n" << C_RESET;
        double mem_saved = 100.0 * (1.0 - s_mem / (f_mem > 0 ? f_mem : 1));
        std::cout << "Memory Reduction:      " << C_CYAN << std::fixed << std::setprecision(1) << mem_saved << "% lower footprint\n" << C_RESET;
        std::cout << C_YELLOW << "===========================================================\n" << C_RESET;
        
        return 0;
    }

    if (run_fifo && !run_srpt) {
        BenchResult fifo_res = run_benchmark(target_dir, true);
        std::lock_guard<std::mutex> lock(print_mutex);
        std::cout << "\n" << C_RED << "-> Execution Time (Wall-Clock): " << std::fixed << std::setprecision(2) << fifo_res.wall_time << " s\n"
                  << "-> OS CPU Time: " << (fifo_res.utime + fifo_res.stime) << " s\n"
                  << "-> Baseline Peak Memory: " << (fifo_res.maxrss / 1024.0) << " MB\n" << C_RESET;
    } 
    else if (run_srpt && !run_fifo) {
        BenchResult srpt_res = run_benchmark(target_dir, false);
        std::lock_guard<std::mutex> lock(print_mutex);
        std::cout << "\n" << C_GREEN << "-> Execution Time (Wall-Clock): " << std::fixed << std::setprecision(2) << srpt_res.wall_time << " s\n"
                  << "-> OS CPU Time: " << (srpt_res.utime + srpt_res.stime) << " s\n"
                  << "-> Optimized Peak Memory: " << (srpt_res.maxrss / 1024.0) << " MB\n" << C_RESET;
    }

    return 0;
}

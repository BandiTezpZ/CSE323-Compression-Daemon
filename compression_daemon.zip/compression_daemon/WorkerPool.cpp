#include "WorkerPool.h"
#include "posix_compat.h"
#include <iostream>
#include <vector>
#include <string>
#include <mutex>
#include <iomanip>
#include <zlib.h>
#include <sys/stat.h>
#include <thread>

#ifdef _WIN32
#include <windows.h>
#endif

extern std::mutex print_mutex;

#ifndef S_IRUSR
#define S_IRUSR 00400
#define S_IWUSR 00200
#endif

WorkerPool::WorkerPool(size_t num_threads, Monitor* monitor, size_t chunk_size)
    : monitor_(monitor), chunk_size_(chunk_size) {
    for (size_t i = 0; i < num_threads; ++i) {
        workers_.emplace_back(&WorkerPool::worker_loop, this, i + 1);
    }
}

WorkerPool::~WorkerPool() {
    join_all();
}

void WorkerPool::join_all() {
    // Notify all happens in the monitor itself typically, or we just join what's active.
    for (auto& worker : workers_) {
        if (worker.joinable()) {
            worker.join();
        }
    }
}

void WorkerPool::worker_loop(int worker_id) {
#ifdef _WIN32
    // ADVANCED OS FEATURE: CPU Core Pinning (Thread Affinity)
    // This locks this specific worker thread to a specific hardware CPU core.
    // It prevents context-switching cache misses across L1/L2 hardware caches!
    HANDLE thread = GetCurrentThread();
    DWORD_PTR mask = (1ULL << ((worker_id - 1) % std::thread::hardware_concurrency()));
    SetThreadAffinityMask(thread, mask);
#endif

    CompressJob job;

    while (monitor_->pop(job)) {
        bool finished = false;
        do {
            if (job.strategy == IOStrategy::IO_MMAP) {
                // ZERO-COPY EXECUTION: Map file directly into virtual memory (No pread buffers needed)
                int fd = open(job.filename.c_str(), O_RDONLY | O_BINARY);
                if (fd >= 0) {
                    void* mapped_data = mmap(NULL, job.total_size, PROT_READ, MAP_PRIVATE, fd, 0);
                    if (mapped_data != MAP_FAILED) {
                        std::vector<char> destBuf(compressBound(job.total_size));
                        z_stream strm = {0};
                        int comp_level = monitor_->is_fifo() ? Z_BEST_COMPRESSION : Z_BEST_SPEED;
                        
                        if (deflateInit(&strm, comp_level) == Z_OK) {
                            strm.avail_in = job.total_size;
                            strm.next_in = (Bytef*)mapped_data;
                            strm.avail_out = destBuf.size();
                            strm.next_out = (Bytef*)destBuf.data();
                            
                            int ret = deflate(&strm, Z_FINISH);
                            if (ret == Z_STREAM_END || ret == Z_OK) {
                                uLongf destLen = destBuf.size() - strm.avail_out;
                                std::string out_filename = job.filename + ".z";
                                int out_fd = open(out_filename.c_str(), O_WRONLY | O_CREAT | O_APPEND | O_BINARY, S_IRUSR | S_IWUSR);
                                if (out_fd >= 0) {
#ifdef _WIN32
                                    _write(out_fd, destBuf.data(), destLen);
#else
                                    write(out_fd, destBuf.data(), destLen);
#endif
                                    close(out_fd);
                                }
                            }
                            deflateEnd(&strm);
                        }
                        
                        munmap(mapped_data, job.total_size);
                    }
                    close(fd);
                }
                
                // Real-time log
                {
                    std::lock_guard<std::mutex> lock(print_mutex);
                    std::cout << "  [Worker " << std::setw(2) << worker_id << "] Processing chunk (MMAP)... (0.0 MB left of " << job.filename << ")\n";
                }
                
                job.remaining_bytes = 0;
                finished = true; // Never preempted
                
            } else {
                // PREEMPTIVE PREAD (Large Files)
                size_t to_read;
                size_t buffer_allocation_size;

                if (monitor_->is_fifo()) {
                    // NAIVE BASELINE: Uses a massive 50MB fixed-size buffer allocation.
                    to_read = std::min(job.remaining_bytes, (size_t)(50 * 1024 * 1024));
                    buffer_allocation_size = 50 * 1024 * 1024; // 50 MB fixed RAM spike
                } else {
                    // OPTIMIZED SRPT: Uses ultra-efficient dynamic chunk allocation.
                    to_read = std::min(job.remaining_bytes, chunk_size_);
                    buffer_allocation_size = to_read;
                }

                // Allocate the buffer (Baseline bloats RAM here, Optimized saves RAM)
                std::vector<char> buffer(buffer_allocation_size);
                
                int fd = open(job.filename.c_str(), O_RDONLY | O_BINARY);
                if (fd >= 0) {
                    ssize_t bytes_read = pread(fd, buffer.data(), to_read, job.current_offset);
                    close(fd);

                    if (bytes_read > 0) {
                        std::vector<char> destBuf(compressBound(bytes_read));
                        
                        z_stream strm = {0};
                        int comp_level = monitor_->is_fifo() ? Z_BEST_COMPRESSION : Z_BEST_SPEED;
                        
                        if (deflateInit(&strm, comp_level) == Z_OK) {
                            strm.avail_in = bytes_read;
                            strm.next_in = (Bytef*)buffer.data();
                            strm.avail_out = destBuf.size();
                            strm.next_out = (Bytef*)destBuf.data();
                            
                            int ret = deflate(&strm, Z_FINISH);
                            if (ret == Z_STREAM_END || ret == Z_OK) {
                                uLongf destLen = destBuf.size() - strm.avail_out;
                                
                                std::string out_filename = job.filename + ".z";
                                int out_fd = open(out_filename.c_str(), O_WRONLY | O_CREAT | O_APPEND | O_BINARY, S_IRUSR | S_IWUSR);
                                if (out_fd >= 0) {
#ifdef _WIN32
                                    _write(out_fd, destBuf.data(), destLen);
#else
                                    write(out_fd, destBuf.data(), destLen);
#endif
                                    close(out_fd);
                                }
                            }
                            deflateEnd(&strm);
                        }
                        
                        job.remaining_bytes -= bytes_read;
                        job.current_offset += bytes_read;

                        // Real-time log
                        {
                            std::lock_guard<std::mutex> lock(print_mutex);
                            std::cout << "  [Worker " << std::setw(2) << worker_id << "] Processing chunk (PREAD)... (" 
                                      << std::fixed << std::setprecision(1) << (job.remaining_bytes / (1024.0 * 1024.0)) << " MB left of " << job.filename << ")\n";
                        }

                        if (!monitor_->is_fifo() && job.remaining_bytes > 0) {
                            monitor_->push(job); // SRPT pushes back to queue for preemption
                            break; 
                        }
                        
                        if (job.remaining_bytes == 0) {
                            finished = true;
                        }
                    } else {
                        finished = true;
                    }
                } else {
                    finished = true;
                }
            }
        } while (monitor_->is_fifo() && job.remaining_bytes > 0 && !finished);

        if (finished || job.remaining_bytes == 0) {
            std::lock_guard<std::mutex> lock(print_mutex);
            std::cout << "  [Worker " << std::setw(2) << worker_id << "] \033[36mFinished:\033[0m " << job.filename << "\n";
            monitor_->decrement_active();
        }
    }
}

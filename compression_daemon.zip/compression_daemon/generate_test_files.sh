#!/bin/bash

# Create target directory
mkdir -p target_dir

echo "Generating 1 large file (200MB)..."
# Using 200MB so it completes in a reasonable time, but is large enough to demonstrate chunking and preemption.
head -c 200M </dev/urandom > target_dir/massive.dat

echo "Generating 100 tiny files (10KB each)..."
for i in {1..100}; do
    head -c 10K </dev/urandom > target_dir/tiny_$i.dat
done

echo "Test files generated in target_dir/"
